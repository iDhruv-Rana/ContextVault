# Unstop submission — copy-ready fields

## Project Title
ContextVault — Local-First Privacy Firewall for Generative AI

## Project Description
ContextVault is a privacy-first web application that helps prevent accidental disclosure of sensitive information when users share prompts, documents, support tickets or code with AI tools and external services. It runs locally in the browser, detects credential patterns, payment-card candidates, Indian identity formats, contact information and user-defined sensitive terms, and replaces recognized values with consistent typed placeholders. An explainable detection ledger enables users to review and override individual findings. Users can restore exact placeholders locally within the same session and export a counts-only audit report without including original values. Advisory instruction-risk flags highlight common prompt-injection phrases for review. The prototype combines pattern recognition, contextual rules and checksum validation without a server-side inference pipeline, paid API or account. It is designed for students, developers, support teams and organizations seeking a practical pre-sharing privacy layer. It is a heuristic assistant, not an automatic interception tool or a guarantee against disclosure.

## Technologies / Tools Used
HTML5, CSS3, JavaScript ES Modules, Node.js, regular expressions, Luhn and Verhoeff checksums, in-memory typed pseudonymization, policy-based detection, browser File/Clipboard/Blob APIs, Content Security Policy, Node.js test runner, GitHub Actions CI configuration, and Vercel-ready static deployment configuration.

## GitHub Repository Link
Paste your actual public GitHub repository URL after uploading the source folder. Do not submit a placeholder.

## Live Project / Deployment Link
Paste the actual public Vercel or GitHub Pages URL after deployment and incognito verification.

## Project Demo Video Link
Upload the supplied MP4 to YouTube (Unlisted) or Google Drive (Anyone with the link → Viewer) and paste the actual URL. Confirm the organizer's duration and video rules before using the supplied demo. The video is a narrated walkthrough of actual tested UI states, not a continuous screen recording. Alternatively record your own demonstration.

## Additional Project Details
Innovation: consistent reversible placeholders preserve repeated references without exposing recognized private values; India-oriented identifier candidates and custom terms enable localized policy; a reviewable evidence ledger and counts-only export make the process auditable. All analysis and mappings stay in the browser, with no external inference API. Validation: 22/22 unit tests passed; a 30-case synthetic benchmark produced 90.0% precision, 81.8% recall and 85.7% F1 (exact type/value matching; not production validation). Chromium standalone smoke tests passed. The system intentionally includes manual review and discloses unsupported forms and false positives. Future scope: local NER, multilingual detection, browser extension and enterprise policy support. AI-assisted implementation should be disclosed if required by the competition.
