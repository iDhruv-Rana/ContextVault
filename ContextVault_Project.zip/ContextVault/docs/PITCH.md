# 90-second live pitch / demo

**0–15 seconds:** Every time people paste a support ticket, source code or document into an AI tool, they may accidentally disclose credentials or personal data. Blocking everything makes AI less useful. ContextVault preserves context while masking recognized sensitive values.

**15–35 seconds:** Load Customer support and show the four detected spans. The same email appears twice but receives the same alias. Card candidates are checked with Luhn. Show the source and output side by side.

**35–55 seconds:** Select Developer incident. Show the credential matches and two instruction warning flags. The evidence ledger explains why each match was detected. The flags are review-only, not an injection defense.

**55–70 seconds:** Click Use sanitized text and Restore locally. Show that exact known tokens recover the original text. Export counts and clear the session. The mapping is in memory; no server receives the text.

**70–90 seconds:** We passed 22 unit tests. On 30 synthetic cases, precision was 90%, recall 81.8%, and F1 85.7%. This is an honest prototype benchmark, not a real-world guarantee. Our next step is local multilingual NER and independent evaluation. ContextVault: share the context, not the secrets.

## Judge questions
- Why not a cloud LLM? Sending sensitive data to a classifier would introduce a new disclosure boundary. Local deterministic matching is auditable and cheap.
- Is it AI? No trained model in this release; it is cybersecurity and automation. A local NER model is a future improvement.
- What is the novelty? The integration of reversible consistent aliases, India-oriented detection, manual evidence review, local processing and counts-only auditing. Not a claim of first-ever DLP or anonymization.
- Is it perfect? No. The benchmark deliberately includes errors; review is mandatory.
- Does it work with every AI tool? It is a manual copy/paste or export workflow, not an integration or interception layer.
- How does it scale? Static hosting serves assets; computation happens on each device. Production evaluation and performance testing are future work.
- Is the score confidence? No, it is the sum of policy weights capped at 100, not a calibrated probability.
