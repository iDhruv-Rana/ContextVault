// Pure, dependency-free local detection. No network or persistence.
export const categories = {
  secret: {label:'Credential / secret',weight:35, severity:'Critical'},
  card: {label:'Payment card',weight:30,severity:'High'},
  aadhaar: {label:'Aadhaar candidate',weight:30,severity:'High'},
  pan: {label:'PAN candidate',weight:25,severity:'High'},
  email: {label:'Email address',weight:12,severity:'Medium'},
  phone: {label:'Phone number',weight:12,severity:'Medium'},
  ip: {label:'IPv4 address',weight:8,severity:'Low'},
  account: {label:'Account identifier',weight:25,severity:'High'},
  custom: {label:'Custom sensitive term',weight:20,severity:'High'},
};
export const policies = {standard:Object.keys(categories), strict:Object.keys(categories), developer:['secret','email','ip','custom']};
export const MAX_TEXT=100000;
export function luhn(s){let sum=0; const a=s.replace(/\D/g,''); for(let i=a.length-1,j=0;i>=0;i--,j++){let n=+a[i]*(j%2?2:1);sum+=n>9?n-9:n;}return sum%10===0 && !/^(\d)\1+$/.test(a);}
const d=[[0,1,2,3,4,5,6,7,8,9],[1,2,3,4,0,6,7,8,9,5],[2,3,4,0,1,7,8,9,5,6],[3,4,0,1,2,8,9,5,6,7],[4,0,1,2,3,9,5,6,7,8],[5,9,8,7,6,0,4,3,2,1],[6,5,9,8,7,1,0,4,3,2],[7,6,5,9,8,2,1,0,4,3],[8,7,6,5,9,3,2,1,0,4],[9,8,7,6,5,4,3,2,1,0]];
const p=[[0,1,2,3,4,5,6,7,8,9],[1,5,7,6,2,8,3,0,9,4],[5,8,0,3,7,9,6,1,4,2],[8,9,1,6,0,4,3,5,2,7],[9,4,5,3,1,2,6,8,7,0],[4,2,8,6,5,7,3,9,0,1],[2,7,9,3,8,0,6,4,1,5],[7,0,4,6,9,1,3,2,5,8]];
export function verhoeff(s){const a=s.replace(/\D/g,'');let c=0;[...a].reverse().forEach((n,i)=>c=d[c][p[i%8][+n]]);return c===0;}
const specs=[
 ['secret',/\b(?:sk-[A-Za-z0-9_-]{16,}|gh[pousr]_[A-Za-z0-9_]{20,}|AKIA[A-Z0-9]{16}|AIza[A-Za-z0-9_-]{35})\b/g,0,'Recognized credential prefix'],
 ['secret',/\b(?:api[_ -]?key|access[_ -]?token|client[_ -]?secret|password|passwd|authorization)\s*[:=]\s*["']?(?:Bearer\s+)?([^\s"',;<>]{6,})/gi,1,'Credential assignment context'],
 ['secret',/-----BEGIN (?:[A-Z]+ )?PRIVATE KEY-----[\s\S]*?-----END (?:[A-Z]+ )?PRIVATE KEY-----/g,0,'Private key block'],
 ['email',/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,63}\b/gi,0,'Email syntax'],
 ['pan',/\b[A-Z]{5}[0-9]{4}[A-Z]\b/g,0,'Indian PAN format; not identity verification'],
 ['card',/(?<!\d)(?:\d[ -]?){12,18}\d(?!\d)/g,0,'Payment-card length and Luhn checksum',s=>luhn(s)],
 ['aadhaar',/(?<!\d)[2-9]\d{3}[ -]?\d{4}[ -]?\d{4}(?!\d)/g,0,'12 digits with Verhoeff checksum; not identity verification',s=>verhoeff(s)],
 ['phone',/(?<![\w\d])(?:\+91[ -]?)?[6-9]\d{4}[ -]?\d{5}(?![\w\d])/g,0,'Indian mobile-number pattern'],
 ['phone',/\+[1-9]\d{0,2}[ -]?(?:\d[ -]?){7,12}\d\b/g,0,'International phone candidate'],
 ['ip',/\b(?:\d{1,3}\.){3}\d{1,3}\b/g,0,'IPv4 octets in range',s=>s.split('.').every(n=>+n<=255)],
 ['account',/\b(?:account(?:\s+(?:number|no\.?))?|a\/c)\s*[:=]\s*(\d{9,18})\b/gi,1,'Bank account label context'],
];
const warningRules=[['Instruction override',/ignore\s+(?:all\s+)?(?:previous|prior|above)\s+instructions/gi],['System prompt extraction',/(?:reveal|print|show|expose)\s+(?:the\s+|your\s+)?(?:system prompt|hidden instructions)/gi],['Exfiltration instruction',/(?:send|upload|exfiltrate|forward)\s+(?:all\s+|the\s+)?(?:secrets|credentials|private data|api keys)/gi]];
const esc=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
export function analyze(text,{policy='standard',custom=[]}={}){
 if(typeof text!=='string'||text.length>MAX_TEXT)throw Error('Enter up to 100,000 characters.');
 const allowed=policies[policy]||policies.standard; const candidates=[];
 function add(type,value,start,reason){if(value)candidates.push({type,value,start,end:start+value.length,reason});}
 for(const [type,re,group,reason,valid] of specs){if(!allowed.includes(type))continue;for(const m of text.matchAll(re)){const value=m[group];if(!valid||valid(value))add(type,value,m.index+(group?m[0].lastIndexOf(value):0),reason);}}
 // Strict mode errs on the side of masking contextual ID candidates even without checksum.
 if(policy==='strict')for(const m of text.matchAll(/\b(?:aadhaar|aadhar|uid)\s*(?:number|no\.?)?\s*[:=]\s*([2-9]\d{3}[ -]?\d{4}[ -]?\d{4})\b/gi))add('aadhaar',m[1],m.index+m[0].lastIndexOf(m[1]),'Contextual ID candidate; checksum not required in strict mode');
 for(const term of [...new Set(custom.map(s=>s.trim()).filter(s=>s.length>=2))].slice(0,50)){for(const m of text.matchAll(new RegExp(esc(term),'gi')))add('custom',m[0],m.index,'User-defined sensitive term');}
 // Prefer severity and longer spans; never partially redact overlapping credentials.
 candidates.sort((a,b)=>categories[b.type].weight-categories[a.type].weight||(b.end-b.start)-(a.end-a.start)||a.start-b.start);
 const selected=[];for(const c of candidates){if(!selected.some(s=>c.start<s.end&&c.end>s.start))selected.push(c);}
 selected.sort((a,b)=>a.start-b.start);
 const warnings=warningRules.flatMap(([label,re])=>[...text.matchAll(re)].map(m=>({label,start:m.index,end:m.index+m[0].length})));
 return {findings:selected.map((f,i)=>({...f,id:i})),warnings,score:Math.min(100,selected.reduce((s,f)=>s+categories[f.type].weight,0)+warnings.length*15)};
}
export function sanitize(text,findings,excluded=[]){
 const skip=new Set(excluded), map=new Map(), reverse=new Map();let out='',cursor=0,n=0;let prefix='CV';while(text.includes(`[${prefix}_`))prefix+='X';
 for(const f of [...findings].sort((a,b)=>a.start-b.start)){
  if(f.start<cursor||text.slice(f.start,f.end)!==f.value)throw Error('Findings no longer match the input. Scan again.');
  const key=f.type+'\0'+f.value;let token=reverse.get(key);if(!token){token=`[${prefix}_${f.type.toUpperCase()}_${++n}]`;reverse.set(key,token);}
  if(skip.has(f.id))continue;map.set(token,f.value);
  out+=text.slice(cursor,f.start)+token;cursor=f.end;
 }return {text:out+text.slice(cursor),map};
}
export function restore(text,map){return text.replace(/\[CVX*_[A-Z]+_\d+\]/g,t=>map.get(t)??t);}
export function riskLabel(n){return n>=65?'High':n>=25?'Elevated':n>0?'Low':'No matches';}
export function report(result,excluded=[]){const skipped=new Set(excluded);const counts={};for(const f of result.findings){counts[f.type]=(counts[f.type]||0)+1;}return {schema:'contextvault-report-v1',heuristicRisk:result.score,findings:result.findings.length,redacted:result.findings.filter(f=>!skipped.has(f.id)).length,excluded:result.findings.filter(f=>skipped.has(f.id)).length,categories:counts,warningCount:result.warnings.length,warningTypes:[...new Set(result.warnings.map(w=>w.label))],notice:'Counts only; no input, sensitive values, or mapping included.'};}
